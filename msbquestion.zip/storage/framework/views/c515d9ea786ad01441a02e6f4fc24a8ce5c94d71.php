
<?php $__env->startSection('title', 'প্রশ্নপত্র'); ?>
<?php $__env->startSection('user-content'); ?>
<div class="container">
    <div class="row py-4 align-items-center">
        <!-- For Demo Purpose -->
        <!-- Registeration Form -->
        <div class="col-lg-7  mx-auto">
           
            <div class="appointment px-4 py-4">
                <div class="">
                    <h4>মাল্টিপারপাস হেলথ ভলান্টিয়া ( এমএইচভি)৩ দিন ব্যাপি রিফ্রেশার্স প্রশিক্ষণ চাহিদা নিরুপণ প্রশ্নপত্র ( অনলাইন).</h4>
                </div>
                <hr>
                <form action="<?php echo e(route('registration.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <!-- First Name -->
                        <div class="form-group col-lg-12 mb-3">
                            <label for="name">এমএইচভির নাম <span class="text-danger">*</span></label>
                            <input id="name" type="text" name="name"  class="form-control bg-white <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>" placeholder="নাম" />
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
            
                        <div class="form-group col-lg-6 mb-2">
                            <label for="gender">লিঙ্গ সিলেক্ট করুন  <span class="text-danger">*</span></label> <br>
                            <label for="male"><input type="radio" name="gender" id="male" value="পুরুষ"> পুরুষ</label> <br>
                            <label for="female"> <input type="radio" name="gender" id="female" value="মহিলা"> মহিলা</label> <br>
                            <label for="other"><input type="radio" name="gender" id="other" value="অন্যান্য"> অন্যান্য</label>
                            
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-lg-6 mb-2">
                            <label for="age">বয়স সিলেক্ট করুন <span class="text-danger">*</span></label> <br>
                            <label for="18-20"><input type="radio" name="age" id="18-20" value="১৮-২০"> ১৮-২০</label> <br>
                            <label for="21-30"> <input type="radio" name="age" id="21-30" value="২১-৩০"> ২১-৩০</label> <br>
                            <label for="31-45"><input type="radio" name="age" id="31-45" value="৩১-৪৫"> ৩১-৪৫</label>
                            <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-lg-12 mb-3">
                            <label for="msb_nomination_date">MHV হিসাবে চূড়ান্ত মনোনয়ন পেয়েছেন কোন সালে?<span class="text-danger">*</span></label>
                            <input id="mhv_nomination_date" type="date" name="mhv_nomination_date"  class="form-control bg-white <?php $__errorArgs = ['mhv_nomination_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo date('Y-m-d'); ?>" />
                            <?php $__errorArgs = ['mhv_nomination_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-lg-12 mb-3">
                            <label for="mhv_id_number">MHV আইডি নাম্বার (ইংরেজীতে লিখুন) <span class="text-danger">*</span></label>
                            <input id="mhv_id_number" type="text" name="mhv_id_number"  class="form-control bg-white <?php $__errorArgs = ['mhv_id_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('mhv_id_number')); ?>" placeholder="MHV আইডি" />
                            <?php $__errorArgs = ['mhv_id_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-lg-12 mb-3">
                            <label for="mobile">মোবাইল নাম্বার (ইংরেজীতে লিখুন) <span class="text-danger">*</span></label>
                            <input id="mobile" type="text" name="mobile"  class="form-control bg-white <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('mobile')); ?>" placeholder="মোবাইল " />
                            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-lg-12 mb-3">
                            <label for="cc_name">সিসির নাম (ইংরেজীতে লিখুন) <span class="text-danger">*</span></label>
                            <input id="cc_name" type="text" name="cc_name"  class="form-control bg-white <?php $__errorArgs = ['cc_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('cc_name')); ?>" placeholder="সিসির নাম" />
                            <?php $__errorArgs = ['cc_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-lg-12 mb-3">
                            <label for="email">ইমেইল আইডি (ইংরেজীতে লিখুন) <span class="text-danger">*</span></label>
                            <input id="email" type="text" name="email"  class="form-control bg-white <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" placeholder="ইমেইল আইডি" />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-lg-12 mb-3">
                            <label for="cc_id">সিসির আইডি (ইংরেজীতে লিখুন) <span class="text-danger">*</span></label>
                            <input id="cc_id" type="text" name="cc_id"  class="form-control bg-white <?php $__errorArgs = ['cc_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('cc_id')); ?>" placeholder="সিসির আইডি" />
                            <?php $__errorArgs = ['cc_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-lg-6 mb-3">
                            <label for="district">জেলা নির্বাচন করুন <span class="text-danger">*</span></label>
                            <select name="district" id="distict_area" class="form-control bg-white <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->bn_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['zila'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-lg-6 mb-3">
                            <label for="upazila">উপজেলা নির্বাচন করুন <span class="text-danger">*</span></label>
                            <select name="upazila" id="upazila_area" class="form-control <?php $__errorArgs = ['upazila'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="" class="text-danger">উপজেলা নির্বাচন করুন</option>
                            </select>
                            
                            <?php $__errorArgs = ['upazila'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-lg-6 mb-3">
                            <label for="union">ইউনিয়ন নির্বাচন করুন  <span class="text-danger">*</span></label>
                            <select name="union" id="union_area" class="form-control <?php $__errorArgs = ['union'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="" class="text-danger">ইউনিয়ন নির্বাচন করুন</option>
                            </select>
                            <?php $__errorArgs = ['union'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-lg-6 mb-3">
                            <label for="word">ওয়ার্ড  নাম্বার  (ইংরেজিতে লেখুন)<span class="text-danger">*</span></label>
                            <input id="word" type="text" name="word"  class="form-control bg-white <?php $__errorArgs = ['word'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('word')); ?>" placeholder="ওয়ার্ড নাম্বার" />
                            <?php $__errorArgs = ['word'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                       
                        <div class="form-group col-lg-12 mb-3">
                            <label for="cc_block_no">সিসি-ব্লক নং(ইংরেজীতে লিখুন ) <span class="text-danger">*</span></label>
                            <input id="cc_block_no" type="text" name="cc_block_no"  class="form-control bg-white <?php $__errorArgs = ['cc_block_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('cc_block_no')); ?>" placeholder="সিসি-ব্লক নং" />
                            <?php $__errorArgs = ['cc_block_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- Submit Button -->
                        <div class="form-group pl-3 mb-0">
                            <a href="<?php echo e(route('question')); ?>" class="btn btn-info btn-block py-2 px-4">
                                <span class="font-weight-bold">Next</span>
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    $('#distict_area').change(function(){
        var district = $('#distict_area').val();
        $('#upazila_area').html();
        var option = "";
        $.get("/get-upazila/"+district, function(data){
            //data = JSON.parse(data)
            //console.log(data);
            data.forEach(el => {
                //console.log(el.name)
                option += "<option value='"+el.id+"'>"+el.bn_name+"</option>"
            });
            $('#upazila_area').html(option);
        })
    })
    $('#upazila_area').change(function(){
        var district = $('#upazila_area').val();
        $('#union_area').html();
        var option = "";
        $.get("/get-union/"+district, function(data){
            //data = JSON.parse(data)
            //console.log(data);
            data.forEach(el => {
                //console.log(el.name)
                option += "<option value='"+el.id+"'>"+el.bn_name+"</option>"
            });
            $('#union_area').html(option);
        })
    })
</script>
<script>
    $(document).ready(function () {
            $("#myselect").change(function () {
                // var selectedVal = $("#myselect option:selected").text();
                var selectedVal = $("#myselect option:selected").attr("id");
                if(selectedVal == "toggle"){
                    $("#content").show();
                } else{
                    $("#content").hide();
                }
                console.log("|"+selectedVal);
            });
        });
    $(document).ready(function () {
        $("#areaselect").change(function () {
            // var selectedVal = $("#areaselect option:selected").text();
            var selectedVal = $("#areaselect option:selected").attr("id");
            if(selectedVal == "areatoggle"){
                $("#areacontent").show();
            } else{
                $("#areacontent").hide();
            }
            console.log("|"+selectedVal);
        });
    });
</script>    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.userMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\msbquestion\resources\views/pages/home.blade.php ENDPATH**/ ?>