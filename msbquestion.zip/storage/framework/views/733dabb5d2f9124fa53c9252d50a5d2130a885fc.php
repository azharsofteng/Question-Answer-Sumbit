
<?php $__env->startSection('title', 'প্রশ্নপত্র'); ?>
<?php $__env->startSection('user-content'); ?>
<div class="container">
    <div class="row py-4 align-items-center">
        <!-- For Demo Purpose -->
        <!-- Registeration Form -->
        <div class="col-lg-7  mx-auto">
           
            <div class="appointment px-4 py-4">
                <div class="">
                    <h4>মাল্টিপারপাস হেলথ ভলান্টিয়া ( এমএইচভি)৩ দিন ব্যাপি রিফ্রেশার্স প্রশিক্ষণ চাহিদা নিরুপণ প্রশ্নপত্র ( অনলাইন).</h4>
                </div>
                <hr>
                <form action="<?php echo e(route('registration.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <!-- First Name -->
                        <div class="form-group col-lg-12 mb-2">
                            <label for="gender">১। আপনি কি ৫ দিন ব্যাপি মৌলিক    প্রশিক্ষণ পেয়েছেন?<br>
                            <label class="ml-4" for="male"><input type="radio" name="gender" id="male" value="হ্যাঁ"> হ্যাঁ</label> <br>
                            <label class="ml-4" for="female"> <input type="radio" name="gender" id="female" value="না"> না</label> <br>
                            
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group col-lg-12 mb-2">
                            <label for="age">২। কত সালে মৌলিক প্রশিক্ষণ পেয়েছেন ? <br>
                            <label class="ml-4" for="18-20"><input type="radio" name="age" id="18-20" value="২০১৮"> ২০১৮</label> <br>
                            <label class="ml-4" for="21-30"> <input type="radio" name="age" id="21-30" value="২০১৯"> ২০১৯</label> <br>
                            <label class="ml-4" for="31-45"><input type="radio" name="age" id="31-45" value="২০২০"> ২০২০</label><br>
                            <label class="ml-4" for="31-45"><input type="radio" name="age" id="31-45" value="২০২১"> ২০২১</label>
                            <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group col-lg-12 mb-2">
                            <label for="gender">৩। ৫ দিনব্যপী  মৌলিক  প্রশিক্ষণ  ব্যাতীত আর কোন  প্রশিক্ষণ পেয়েছেন?<br>
                            <label class="ml-4" for="male"><input type="radio" name="gender" id="male" value="হ্যাঁ"> হ্যাঁ</label> <br>
                            <label class="ml-4" for="female"> <input type="radio" name="gender" id="female" value="না"> না</label> <br>
                            
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-lg-12 mb-2">
                            <label for="gender">৪। যদি হ্যাঁ হয় উল্লেখ করুন কী কী বিষয়ে প্রশিক্ষণ পেয়েছেন?<br>
                            <label class="ml-4" for="male"><input type="checkbox" name="gender" id="male" value="MHV অ্যাপ্লিকেশন"> MHV অ্যাপ্লিকেশন</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="PRIMA অ্যাপ্লিকেশন"> PRIMA অ্যাপ্লিকেশন</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="খানা ভিত্তিক তথ্য সংগ্রহ"> খানা ভিত্তিক তথ্য সংগ্রহ</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="খানা ভিত্তিক তথ্য সংগ্রহ"> খানা ভিত্তিক তথ্য সংগ্রহ</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="ইপিআই"> ইপিআই</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="ভিটামিন A+ ক্যাম্পেইন"> ভিটামিন A+ ক্যাম্পেইন </label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="কোভিড -১৯ "> কোভিড -১৯  </label> <br>
                            
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-lg-12 mb-2">
                            <label for="gender">৫। কমিউনিটি ক্লিনিকের ব্যবস্থপনায় কমিউনিটি গ্রুপ / সাপোর্ট  গ্রুপ সভা কার্যক্রম সম্পর্কে আপনি কি প্রশিক্ষণ পেয়েছেন ?<br>
                            <label class="ml-4" for="male"><input type="radio" name="gender" id="male" value="হ্যাঁ"> হ্যাঁ</label> <br>
                            <label class="ml-4" for="female"> <input type="radio" name="gender" id="female" value="না"> না</label> <br>
                            
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group col-lg-12 mb-2">
                            <label for="gender">৬। খানা পর্যায়ে স্বাস্থ্যসেবা প্রদানে অ্যাপস ভিত্তিক কর্ম সম্পাদনে আপনার সমস্যাসমহূ চিহ্নিত করুন:<br>
                            <label class="ml-4" for="male"><input type="checkbox" name="gender" id="male" value="MHV অ্যাপ্লিকেশন"> MHV অ্যাপ্লিকেশন</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="PRIMA অ্যাপ্লিকেশন"> PRIMA অ্যাপ্লিকেশন</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="খানা ভিত্তিক তথ্য সংগ্রহ"> খানা ভিত্তিক তথ্য সংগ্রহ</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="খানা ভিত্তিক তথ্য সংগ্রহ"> খানা ভিত্তিক তথ্য সংগ্রহ</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="ইপিআই"> ইপিআই</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="ভিটামিন A+ ক্যাম্পেইন"> ভিটামিন A+ ক্যাম্পেইন </label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="কোভিড -১৯ "> কোভিড -১৯  </label> <br>
                            
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-lg-12 mb-2">
                            <label for="gender">৭। খানা পর্যায়ে স্বাস্থ্যসেবা প্রদানেরক্ষেত্রে কী কী বিষয় প্রয়োজনীয় বলে মনে করেন?<br>
                            <label class="ml-4" for="male"><input type="checkbox" name="gender" id="male" value="MHV অ্যাপ্লিকেশন"> MHV অ্যাপ্লিকেশন</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="PRIMA অ্যাপ্লিকেশন"> PRIMA অ্যাপ্লিকেশন</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="খানা ভিত্তিক তথ্য সংগ্রহ"> খানা ভিত্তিক তথ্য সংগ্রহ</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="খানা ভিত্তিক তথ্য সংগ্রহ"> খানা ভিত্তিক তথ্য সংগ্রহ</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="ইপিআই"> ইপিআই</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="ভিটামিন A+ ক্যাম্পেইন"> ভিটামিন A+ ক্যাম্পেইন </label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="কোভিড -১৯ "> কোভিড -১৯  </label> <br>
                            
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group col-lg-12 mb-2">
                            <label for="gender">৮। কোভিড-১৯ প্রতিরোধও স্বাস্থ্যসুরক্ষা বিষয় সমহেূহের মধ্যে কী বিষয়ে আপনার প্রশিক্ষণ পাওয়া প্রয়োজন<br>
                            <label class="ml-4" for="male"><input type="radio" name="gender" id="male" value="হ্যাঁ"> হ্যাঁ</label> <br>
                            <label class="ml-4" for="female"> <input type="radio" name="gender" id="female" value="না"> না</label> <br>
                            
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-lg-12 mb-2">
                            <label for="gender">৯। মএইচভি (MHV) কর্মপরিদি  অনুযায়ী ডিজিটাল অ্যাপস এর ব্যবহার কী কী ক্ষেত্রে বেশি ব্যবহার হয়েছে ?<br>
                            <label class="ml-4" for="male"><input type="checkbox" name="gender" id="male" value="MHV অ্যাপ্লিকেশন"> MHV অ্যাপ্লিকেশন</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="PRIMA অ্যাপ্লিকেশন"> PRIMA অ্যাপ্লিকেশন</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="খানা ভিত্তিক তথ্য সংগ্রহ"> খানা ভিত্তিক তথ্য সংগ্রহ</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="খানা ভিত্তিক তথ্য সংগ্রহ"> খানা ভিত্তিক তথ্য সংগ্রহ</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="ইপিআই"> ইপিআই</label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="ভিটামিন A+ ক্যাম্পেইন"> ভিটামিন A+ ক্যাম্পেইন </label> <br>
                            <label class="ml-4" for="female"> <input type="checkbox" name="gender" id="female" value="কোভিড -১৯ "> কোভিড -১৯  </label> <br>
                            
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group pl-3 mb-0 ">
                            <a href="<?php echo e(route('question')); ?>" class="btn btn-primary btn-block py-2 px-4">
                                <span class="font-weight-bold">Submit</span>
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.userMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\msbquestion\resources\views/pages/question.blade.php ENDPATH**/ ?>