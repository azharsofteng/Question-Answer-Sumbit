<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                
                <a class="nav-link <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                
                
                
                
                <a class="nav-link <?php echo e(Request::is('table') ? 'active' : ''); ?>" href="<?php echo e(route('table')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                    Ans List
                </a>
                
                <a class="nav-link" href="<?php echo e(route('logout')); ?>">
                    <div class="sb-nav-link-icon"><i class="fa fa-sign-out-alt"></i></div>
                    Logout
                </a>
            </div>
        </div>
    </nav>
</div><?php /**PATH C:\laragon\www\msbquestion\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>