<footer class="py-3 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted common-text">Copyright &copy; <?php echo e(date('Y')); ?> Company Name</div>
            <div class="common-text text-muted">
                Develop By -
                <a class="text-decoration-none" target="_blank" href="http://linktechbd.com/">Link-Up Technology Ltd.</a>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\softadmin\resources\views/partials/footer.blade.php ENDPATH**/ ?>