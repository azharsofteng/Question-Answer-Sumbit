<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <!-- CSRF Token -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>মাল্টিপারপাস হেলথ ভলান্টিয়া ( এমএইচভি) | <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/user-style.css')); ?>">
</head>
<body>
    <?php echo $__env->yieldContent('user-content'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>
</html><?php /**PATH C:\laragon\www\msbquestion\resources\views/layouts/userMaster.blade.php ENDPATH**/ ?>